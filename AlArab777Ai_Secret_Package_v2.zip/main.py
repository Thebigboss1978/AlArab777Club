# Entry point for AlArab777Ai

print('Running AlArab777Ai...')